import sys
import os
curPath = os.path.abspath(os.path.dirname(__file__))
rootPath = os.path.split(curPath)[0]
sys.path.append(rootPath)
from multiprocessing import  Process
from memory_profiler import profile
import time
from channel_error_c import Error, read_file_str


#@profile
def error_mutation(i, process_num, pr, sub_pr, del_pr, ins_pr, sample_times):

    err_file_name = 'P_error_word/error_word{:03}'.format(i) + '.txt'
    with open (err_file_name,'w') as f:
        for file_index in range(process_num):
            file_name = 'codeword/codeword_threading{:03}'.format(file_index) + '.txt'
            codeword_file = read_file_str(file_name)
            error = Error(codeword_file,pr,sub_pr,del_pr,ins_pr)
            error_seq_table = error.random_sample(sample_times)
            for i in range(len(error_seq_table)):
                f.write((error_seq_table[i])+'\n')



if __name__ == '__main__':
    start_enc = time.perf_counter()
    process_list = []
    process_num = 8
    pr = 0.01
    sub_pr = 0.003
    del_pr = 0.001
    ins_pr = 0.001
    sample_times = 1
    for i in range(process_num):
        p = Process(target=error_mutation,args=(i, process_num, pr, sub_pr, del_pr, ins_pr, sample_times,))
        p.start()
        process_list.append(p)

    for i in process_list:
        p.join()

    print('结束测试')
    end_enc = time.perf_counter()
    unTime_enc = end_enc - start_enc
    print('编码耗时：',unTime_enc)
