import sys
import os
from multiprocessing import Process
import time
import numpy as np
from c_dec_total import read_file_np, vt_dec

#@profile
def decoder(i, code_word_len, vt_k, key_str, process_num):
    """
    Decoder function for parallel processing.

    Parameters:
    i (int): Process index
    code_word_len (int): Length of the code word
    vt_k (int): Value of k for VT decoding
    key_str (int): Keyword for decoding
    process_num (int): Number of processes
    """
    file_name = 'P_error_word/error_word{:03}'.format(i) + '.txt'
    error_seq_table = read_file_np(file_name)
    vt_dec(i, error_seq_table, code_word_len, vt_k, key_str, process_num)

if __name__ == '__main__':
    start_enc = time.perf_counter()
    process_list = []
    process_num = 8
    key_word = 1
    code_word_len = 146
    vt_k = 137
    for i in range(process_num):
        p = Process(target=decoder, args=(i, code_word_len, vt_k, key_word, process_num,))
        p.start()
        process_list.append(p)

    for p in process_list:
        p.join()

    print('Test completed')
    end_enc = time.perf_counter()
    elapsed_time_enc = end_enc - start_enc
    print('Encoding time:', elapsed_time_enc)
