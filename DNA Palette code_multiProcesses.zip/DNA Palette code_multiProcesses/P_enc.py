import sys
import os
from multiprocessing import Process
import time
import random
import numpy as np
from outer_dec_rs_8_c import rs_encode, read_file
from c_inner_enc import enc_word

#@profile
def encoder(i, msg_len, key_word, a_str_len, process_num):
    """
    Encoder function for parallel processing.

    Parameters:
    i (int): Process index
    msg_len (int): Length of the message
    key_word (int): Keyword for encoding
    a_str_len (int): Length of the input string
    process_num (int): Number of processes
    """
    # Randomly generate byte information sequence
    msg_or = bytearray(random.getrandbits(8) for _ in range(msg_len // process_num))

    enc_file_name = 'enc_process_1mb/enc_process{:03}'.format(i) + '.txt'
    with open(enc_file_name, 'wb') as f:
        f.write(bytes(msg_or))

    rs_enc, file_txt_len = rs_encode(msg_or, a_str_len // 4)

    file_name = 'codeword'
    minus_num, codeword_num, code_word_len, vt_k = enc_word(rs_enc, a_str_len * 2, i, process_num, key_word, file_name)

    print('Parameters:', minus_num, codeword_num, code_word_len, vt_k, len(rs_enc), file_txt_len)

if __name__ == '__main__':
    start_enc = time.perf_counter()
    process_list = []
    process_num = 8
    key_word = 1
    msg_len = 2 ** 20
    a_str_len = 128
    for i in range(process_num):
        p = Process(target=encoder, args=(i, msg_len, key_word, a_str_len, process_num,))
        p.start()
        process_list.append(p)

    for p in process_list:
        p.join()

    print('Test completed')
    end_enc = time.perf_counter()
    elapsed_time_enc = end_enc - start_enc
    print('Encoding time:', elapsed_time_enc)
