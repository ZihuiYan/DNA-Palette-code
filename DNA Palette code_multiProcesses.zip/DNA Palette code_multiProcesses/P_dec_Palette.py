import sys
import os
from multiprocessing import Process
import time
import numpy as np
from c_dec_total import read_file_np, cds_decode, rs_decode, check_function
from c_dec_total import read_file

#@profile
def decoder(i, a_str_len, enc_binary_len, file_len, process_num):
    """
    Decoder function for parallel processing.

    Parameters:
    i (int): Process index
    a_str_len (int): Length of a_str
    enc_binary_len (int): Length of the encoded binary
    file_len (int): Length of the file
    process_num (int): Number of processes
    """
    vt_code_list = []
    for j in range(process_num):
        file_name = 'id_dec/id_dec_{:03}'.format(j) + '/id_dec{:03}'.format(i) + '.txt'
        vt_code_list.extend(read_file_np(file_name))

    rs_byte_arr = cds_decode(vt_code_list, a_str_len * 2, enc_binary_len)
    codeword = rs_decode(rs_byte_arr, file_len, a_str_len // 4)

    enc_file_name = 'enc_process_1mb/enc_process{:03}'.format(i) + '.txt'

    print('Process Number:', i)
    print('Number of Errors:', check_function(read_file(enc_file_name), codeword))
    print('------------------------')

if __name__ == '__main__':
    start_enc = time.perf_counter()
    process_list = []
    process_num = 8
    a_str_len = 128
    enc_binary_len = 1204224
    file_len = 131072
    for i in range(process_num):
        p = Process(target=decoder, args=(i, a_str_len, enc_binary_len, file_len, process_num,))
        p.start()
        process_list.append(p)

    for p in process_list:
        p.join()

    print('Test completed')
    end_enc = time.perf_counter()
    elapsed_time_enc = end_enc - start_enc
    print('Encoding time:', elapsed_time_enc)
