# setup.py
from setuptools import setup, Extension
from Cython.Build import cythonize
import numpy as np

#python setup.py build_ext --inplace


ext_modules = [
    Extension("creedsolo", ["creedsolo.pyx"],
              include_dirs=[np.get_include()]),Extension("c_inner_enc", ["c_inner_enc.pyx"],
              include_dirs=[np.get_include()]), Extension("vt", ["vt.pyx"],
              include_dirs=[np.get_include()]), Extension("outer_dec_rs_8_c", ["outer_dec_rs_8_c.pyx"],
              include_dirs=[np.get_include()]), Extension("c_dec_total", ["c_dec_total.pyx"],
              include_dirs=[np.get_include()]), Extension("channel_error_c", ["channel_error_c.pyx"],
              include_dirs=[np.get_include()]), Extension("oneP_c_dec", ["oneP_c_dec.pyx"],
              include_dirs=[np.get_include()]), Extension("oneP_c_inner_enc", ["oneP_c_inner_enc.pyx"],
              include_dirs=[np.get_include()]), Extension("oneP_c_dec_2", ["oneP_c_dec_2.pyx"],
              include_dirs=[np.get_include()])  # Add the NumPy header files
]

setup(
    name='pytest',
    ext_modules=cythonize(ext_modules)
)
'''
ext_modules = [
   Extension("vt", ["vt.pyx"],
              include_dirs=[np.get_include()]) # Add the NumPy header files
]

setup(
    name='vt',
    ext_modules=cythonize(ext_modules)
)
'''